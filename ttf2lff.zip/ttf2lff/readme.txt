
C:\Users\aupu_zk_harry\Desktop\ttf2lff_1\ttf2lff>ttf2lff.exe simsun.ttc simsun.lff
TTF file: simsun.ttc
LFF file: simsun.lff
family: SimSun
height: 292
ascender: 220
descender: -36
factor: 0.0502793

C:\Users\aupu_zk_harry\Desktop\ttf2lff_1\ttf2lff>


https://forum.librecad.org/Using-ttf2lff-for-windows-td5708647.html

Mini Howto for using ttf2lff in windows

1, download ttf2lff for windows from here: ttf2lff_1.zip

2, unzip it in a folder like c:\myprograms.
The resulting path to executable are c:\myprograms\ttf2lff\ttf2lff.exe

3, Open a console: click in "start_button->run" and type "cmd.exe" in the opened window.
Ok, you have opened a "console window"

4, In "console window" type the following comand and press Intro:
cd c:\myprograms\ttf2lff

5, You are ready to use, to convert arial.ttf (p.e.) located in windows font directory type:
ttf2lff.exe c:\windows\fonts\arial.ttf arial.lff

6, to use the arial.lff file created copy or move it to a LC fonts folder.